function greeter(person) {
    return "Aca esta , " + person;
}
var user = "Morplenauta";
document.body.innerHTML = greeter(user);
