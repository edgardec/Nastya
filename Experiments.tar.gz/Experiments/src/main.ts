function greeter(person) {
    return "Aca esta , " + person;
}

let user = "Morplenauta";

document.body.innerHTML = greeter(user);

